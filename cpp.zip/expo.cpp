#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct Proceso {
    string nombre;
    int prioridad;
    Proceso* siguiente;
};

Proceso* listaProcesos = NULL;

void agregarProceso() {
    cin.ignore();
    Proceso* nuevo = new Proceso();
    cout << "Ingrese nombre del proceso: ";
    getline(cin, nuevo->nombre);
    cout << "Ingrese prioridad del proceso (1-10): ";
    cin >> nuevo->prioridad;
    nuevo->siguiente = NULL;

    if (listaProcesos == NULL) {
        listaProcesos = nuevo;
    } else {
        Proceso* actual = listaProcesos;
        while (actual->siguiente != NULL) {
            actual = actual->siguiente;
        }
        actual->siguiente = nuevo;
    }
    cout << "Proceso agregado.\n";
}

void eliminarProceso() {
    cin.ignore();
    if (listaProcesos == NULL) {
        cout << "No hay procesos registrados.\n";
        return;
    }
    string nombre;
    cout << "Ingrese el nombre del proceso a eliminar: ";
    getline(cin, nombre);

    Proceso* actual = listaProcesos;
    Proceso* anterior = NULL;

    while (actual != NULL && actual->nombre != nombre) {
        anterior = actual;
        actual = actual->siguiente;
    }

    if (actual == NULL) {
        cout << "Proceso no encontrado.\n";
        return;
    }

    if (anterior == NULL) {
        listaProcesos = actual->siguiente;
    } else {
        anterior->siguiente = actual->siguiente;
    }
    delete actual;
    cout << "Proceso eliminado.\n";
}

void mostrarProcesos() {
    if (listaProcesos == NULL) {
        cout << "No hay procesos registrados.\n";
        return;
    }
    Proceso* actual = listaProcesos;
    cout << "\nLista de procesos:\n";
    while (actual != NULL) {
        cout << "- Nombre: " << actual->nombre << " | Prioridad: " << actual->prioridad << endl;
        actual = actual->siguiente;
    }
}

void buscarProcesoPorNombre() {
    cin.ignore();
    if (listaProcesos == NULL) {
        cout << "No hay procesos registrados.\n";
        return;
    }
    string nombre;
    cout << "Ingrese el nombre del proceso a buscar: ";
    getline(cin, nombre);

    Proceso* actual = listaProcesos;
    while (actual != NULL) {
        if (actual->nombre == nombre) {
            cout << "Proceso encontrado: " << actual->nombre << " | Prioridad: " << actual->prioridad << endl;
            return;
        }
        actual = actual->siguiente;
    }
    cout << "Proceso no encontrado.\n";
}

void modificarPrioridad() {
    cin.ignore();
    if (listaProcesos == NULL) {
        cout << "No hay procesos registrados.\n";
        return;
    }
    string nombre;
    cout << "Ingrese el nombre del proceso a modificar: ";
    getline(cin, nombre);

    Proceso* actual = listaProcesos;
    while (actual != NULL) {
        if (actual->nombre == nombre) {
            cout << "Prioridad actual: " << actual->prioridad << endl;
            cout << "Ingrese nueva prioridad: ";
            cin >> actual->prioridad;
            cout << "Prioridad modificada con exito.\n";
            return;
        }
        actual = actual->siguiente;
    }
    cout << "Proceso no encontrado.\n";
}

Proceso* frenteCola = NULL;
Proceso* finCola = NULL;

void encolarProcesoCPU() {
    cin.ignore();
    Proceso* nuevo = new Proceso();
    cout << "Nombre del proceso: ";
    getline(cin, nuevo->nombre);
    cout << "Prioridad (1-10): ";
    cin >> nuevo->prioridad;
    nuevo->siguiente = NULL;

    if (frenteCola == NULL) {
        frenteCola = finCola = nuevo;
    } else {
        finCola->siguiente = nuevo;
        finCola = nuevo;
    }
    cout << "Proceso encolado.\n";
}

void desencolarProcesoCPU() {
    if (frenteCola == NULL) {
        cout << "La cola de procesos esta vacia.\n";
        return;
    }
    Proceso* temp = frenteCola;
    frenteCola = frenteCola->siguiente;
    cout << "Ejecutando proceso: " << temp->nombre << endl;
    delete temp;
}

void mostrarColaCPU() {
    if (frenteCola == NULL) {
        cout << "La cola de procesos esta vacia.\n";
        return;
    }
    Proceso* actual = frenteCola;
    cout << "\nCola de procesos:\n";
    while (actual != NULL) {
        cout << "- " << actual->nombre << " | Prioridad: " << actual->prioridad << endl;
        actual = actual->siguiente;
    }
}

Proceso* topePila = NULL;

void asignarMemoria() {
    cin.ignore();
    Proceso* nuevo = new Proceso();
    cout << "Proceso a asignar memoria: ";
    getline(cin, nuevo->nombre);
    nuevo->siguiente = topePila;
    topePila = nuevo;
    cout << "Memoria asignada al proceso.\n";
}

void liberarMemoria() {
    if (topePila == NULL) {
        cout << "No hay bloques de memoria asignados.\n";
        return;
    }
    Proceso* temp = topePila;
    topePila = topePila->siguiente;
    cout << "Memoria liberada del proceso: " << temp->nombre << endl;
    delete temp;
}

void mostrarMemoria() {
    if (topePila == NULL) {
        cout << "No hay memoria asignada.\n";
        return;
    }
    Proceso* actual = topePila;
    cout << "\nPila de memoria:\n";
    while (actual != NULL) {
        cout << "- " << actual->nombre << endl;
        actual = actual->siguiente;
    }
}

void menuPrincipal() {
    int opcion;
    do {
        cout << "\n===== SISTEMA DE GESTION DE PROCESOS =====\n";
        cout << "1. Gestor de Procesos (Lista)\n";
        cout << "2. Planificador de CPU (Cola)\n";
        cout << "3. Gestor de Memoria (Pila)\n";
        cout << "4. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch(opcion) {
            case 1: {
                int op;
                do {
                    cout << "\n--- GESTOR DE PROCESOS ---\n";
                    cout << "1. Agregar\n2. Eliminar\n3. Mostrar\n4. Buscar proceso\n5. Modificar prioridad\n6. Volver\nOpcion: ";
                    cin >> op;
                    switch(op) {
                        case 1: agregarProceso(); break;
                        case 2: eliminarProceso(); break;
                        case 3: mostrarProcesos(); break;
                        case 4: buscarProcesoPorNombre(); break;
                        case 5: modificarPrioridad(); break;
                    }
                } while(op != 6);
                break;
            }
            case 2: {
                int op;
                do {
                    cout << "\n--- PLANIFICADOR DE CPU ---\n";
                    cout << "1. Encolar\n2. Desencolar\n3. Mostrar\n4. Volver\nOpcion: ";
                    cin >> op;
                    switch(op) {
                        case 1: encolarProcesoCPU(); break;
                        case 2: desencolarProcesoCPU(); break;
                        case 3: mostrarColaCPU(); break;
                    }
                } while(op != 4);
                break;
            }
            case 3: {
                int op;
                do {
                    cout << "\n--- GESTOR DE MEMORIA ---\n";
                    cout << "1. Asignar\n2. Liberar\n3. Mostrar\n4. Volver\nOpcion: ";
                    cin >> op;
                    switch(op) {
                        case 1: asignarMemoria(); break;
                        case 2: liberarMemoria(); break;
                        case 3: mostrarMemoria(); break;
                    }
                } while(op != 4);
                break;
            }
            case 4: cout << "Saliendo del sistema...\n"; break;
            default: cout << "Opcion invalida. Intente de nuevo.\n";
        }
    } while(opcion != 4);
}

int main() {
    menuPrincipal();
    return 0;
}
